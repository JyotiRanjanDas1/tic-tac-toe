import streamlit as st
import random
import time

st.title("❌⭕ Tic Tac Toe")

# Initialize session state
if "board" not in st.session_state:
    st.session_state.board = [""] * 9

if "game_over" not in st.session_state:
    st.session_state.game_over = False

if "message" not in st.session_state:
    st.session_state.message = ""


# Check winner
def check_winner(board, player):

    win_patterns = [
        [0,1,2],[3,4,5],[6,7,8],
        [0,3,6],[1,4,7],[2,5,8],
        [0,4,8],[2,4,6]
    ]

    for pattern in win_patterns:
        if all(board[i] == player for i in pattern):
            return True

    return False


# Check draw
def check_draw(board):
    return "" not in board


# Computer move
def computer_move():

    empty_cells = [i for i,v in enumerate(st.session_state.board) if v == ""]

    if empty_cells:
        move = random.choice(empty_cells)
        st.session_state.board[move] = "O"


# Player move
def play_move(i):

    if st.session_state.board[i] == "" and not st.session_state.game_over:

        st.session_state.board[i] = "X"

        if check_winner(st.session_state.board, "X"):
            st.session_state.message = "🎉 You Win!"
            st.session_state.game_over = True
            st.rerun()

        if check_draw(st.session_state.board):
            st.session_state.message = "🤝 It's a Draw!"
            st.session_state.game_over = True
            st.rerun()

        st.session_state.message = "🤖 Computer thinking..."
        st.rerun()


# Computer turn
if st.session_state.message == "🤖 Computer thinking..." and not st.session_state.game_over:

    time.sleep(0.7)

    computer_move()

    if check_winner(st.session_state.board, "O"):
        st.session_state.message = "💻 Computer Wins!"
        st.session_state.game_over = True

    elif check_draw(st.session_state.board):
        st.session_state.message = "🤝 It's a Draw!"
        st.session_state.game_over = True

    else:
        st.session_state.message = ""

    st.rerun()


# Game board UI
for row in range(3):

    cols = st.columns(3)

    for col in range(3):

        idx = row*3 + col

        with cols[col]:

            symbol = st.session_state.board[idx] if st.session_state.board[idx] else " "

            if st.button(symbol, key=idx):
                play_move(idx)


# Display message
if st.session_state.message:
    st.subheader(st.session_state.message)


# Reset game
if st.button("🔄 Reset Game"):
    st.session_state.board = [""] * 9
    st.session_state.game_over = False
    st.session_state.message = ""
    st.rerun()