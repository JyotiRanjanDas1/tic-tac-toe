import streamlit as st
import random

st.title("🎮 Stone Paper Scissors")

# Choices with emojis
choices = {
    "stone": "🪨",
    "paper": "📄",
    "scissors": "✂️"
}

# Score initialization
if "user_score" not in st.session_state:
    st.session_state.user_score = 0

if "computer_score" not in st.session_state:
    st.session_state.computer_score = 0


st.subheader("Choose your move")

col1, col2, col3 = st.columns(3)

user_choice = None

with col1:
    if st.button("🪨 Stone"):
        user_choice = "stone"

with col2:
    if st.button("📄 Paper"):
        user_choice = "paper"

with col3:
    if st.button("✂️ Scissors"):
        user_choice = "scissors"


if user_choice:

    computer_choice = random.choice(list(choices.keys()))

    st.divider()

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("🧑 You")
        st.markdown(f"# {choices[user_choice]}")

    with col2:
        st.subheader("🤖 Computer")
        st.markdown(f"# {choices[computer_choice]}")

    st.divider()

    if user_choice == computer_choice:
        st.info("🤝 It's a Tie!")

    elif (
        (user_choice == "stone" and computer_choice == "scissors") or
        (user_choice == "paper" and computer_choice == "stone") or
        (user_choice == "scissors" and computer_choice == "paper")
    ):
        st.success("🎉 You Win!")
        st.session_state.user_score += 1

    else:
        st.error("💻 Computer Wins!")
        st.session_state.computer_score += 1


st.divider()

st.subheader("🏆 Scoreboard")

col1, col2 = st.columns(2)

with col1:
    st.metric("You", st.session_state.user_score)

with col2:
    st.metric("Computer", st.session_state.computer_score)


if st.button("🔄 Reset Game"):
    st.session_state.user_score = 0
    st.session_state.computer_score = 0